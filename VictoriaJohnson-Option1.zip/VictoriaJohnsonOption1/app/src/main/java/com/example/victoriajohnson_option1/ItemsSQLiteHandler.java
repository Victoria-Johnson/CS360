package com.example.victoriajohnson_option1;

public class ItemsSQLiteHandler {
    public void deleteItem(Item item) {
    }

    public Object getAllItems() {
        return null;
    }

    public int getItemsCount() {
        return 0;
    }

    public void updateItem(Item item) {

    }
}
