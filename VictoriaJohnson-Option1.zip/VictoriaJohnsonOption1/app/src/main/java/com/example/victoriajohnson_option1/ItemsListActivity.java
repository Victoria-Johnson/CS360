package com.example.victoriajohnson_option1;

import android.app.Activity;

public class ItemsListActivity extends Activity {
    public static void YesDeleteItems() {

    }

    public static void NoDeleteItems() {
    }

    public static void AllowSendSMS() {
        
    }

    public static void DenySendSMS() {

    }
}
